# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'demo_ui.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################
import os
import sys
import json
import RLPy
import PySide2

import time
import math
from ctypes import *

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
from PySide2.QtUiTools import QUiLoader
from PySide2.QtCore import Signal, QObject, Slot
from shiboken2 import wrapInstance
from threading import Thread
from scipy.spatial.transform import Rotation as R
from scipy import linalg
import numpy as np


MAX_SEGMENT_NUM = 150
CHINGMU_SEGMENT_NUM = 63

rl_plugin_info = {"ap": "iClone", "ap_version": "8.0"}

mocap_dlg = None # mocap dialog
mocap_avatar = None # avatar

# network
ip_port = None
host = None
humanID = 0
# mocap
mocap_manager = RLPy.RGlobal.GetMocapManager()
body_device = None
do_mocap = False
is_connected = False
t_pose_data = []
frame_data = []

is_recvdata = False
cmVrpn= None #VRPN dll


#{bone_name, parent_bone_name, Hik_bone_name}
# 23 bones
hips = ["hips", "", "Hips"]
spine = ["spine", "hips", "Spine"]
spine1 = ["spine1", "spine", "Spine3"]
spine2 = ["spine2", "spine1", "Spine6"]
spine3 = ["spine3", "spine2", "Spine9"]
leftshoulder = ["leftshoulder", "spine3", "LeftShoulder"]
leftarm = ["leftarm", "leftshoulder", "LeftArm"]
leftforearm = ["leftforearm", "leftarm", "LeftForeArm"]
lefthand = ["lefthand", "leftforearm", "LeftHand"]
rightshoulder = ["rightshoulder", "spine3", "RightShoulder"]
rightarm = ["rightarm", "rightshoulder", "RightArm"]
rightforearm = ["rightforearm", "rightarm", "RightForeArm"]
righthand = ["righthand", "rightforearm", "RightHand"]
neck = ["neck", "spine3", "Neck"]
head = ["head", "neck", "Head"]
leftupleg = ["leftupleg", "hips", "LeftUpLeg"]
leftleg = ["leftleg", "leftupleg", "LeftLeg"]
leftfoot = ["leftfoot", "leftleg", "LeftFoot"]
lefttoebase = ["lefttoebase","leftfoot","LeftToeBase"]
rightupleg = ["rightupleg", "hips", "RightUpLeg"]
rightleg = ["rightleg", "rightupleg", "RightLeg"]
rightfoot = ["rightfoot", "rightleg", "RightFoot"]
righttoebase = ["righttoebase","rightfoot","RightToeBase"]
lefthandthumb1 = ["lefthandthumb1", "lefthand", "LeftHandThumb1"]
lefthandthumb2 = ["lefthandthumb2", "lefthandthumb1", "LeftHandThumb2"]
lefthandthumb3 = ["lefthandthumb3", "lefthandthumb2", "LeftHandThumb3"]
leftinhandindex = ["leftinhandindex", "lefthand", "LeftInHandIndex"]
lefthandindex1 = ["lefthandindex1", "leftinhandindex", "LeftHandIndex1"]
lefthandindex2 = ["lefthandindex2", "lefthandindex1", "LeftHandIndex2"]
lefthandindex3 = ["lefthandindex3", "lefthandindex2", "LeftHandIndex3"]
leftinhandmiddle = ["leftinhandmiddle", "lefthand", "LeftInHandMiddle"]
lefthandmiddle1 = ["lefthandmiddle1", "leftinhandmiddle", "LeftHandMiddle1"]
lefthandmiddle2 = ["lefthandmiddle2", "lefthandmiddle1", "LeftHandMiddle2"]
lefthandmiddle3 = ["lefthandmiddle3", "lefthandmiddle2", "LeftHandMiddle3"]
leftinhandring = ["leftinhandring", "lefthand", "LeftInHandRing"]
lefthandring1 = ["lefthandring1", "leftinhandring", "LeftHandRing1"]
lefthandring2 = ["lefthandring2", "lefthandring1", "LeftHandRing2"]
lefthandring3 = ["lefthandring3", "lefthandring2", "LeftHandRing3"]
leftinhandpinky = ["leftinhandpinky", "lefthand", "LeftInHandPinky"]
lefthandpinky1 = ["lefthandpinky1", "leftinhandpinky", "LeftHandPinky1"]
lefthandpinky2 = ["lefthandpinky2", "lefthandpinky1", "LeftHandPinky2"]
lefthandpinky3 = ["lefthandpinky3", "lefthandpinky2", "LeftHandPinky3"]
righthandthumb1 = ["righthandthumb1", "righthand", "RightHandThumb1"]
righthandthumb2 = ["righthandthumb2", "righthandthumb1", "RightHandThumb2"]
righthandthumb3 = ["righthandthumb3", "righthandthumb2", "RightHandThumb3"]
rightinhandindex = ["rightinhandindex", "righthand", "RightInHandIndex"]
righthandindex1 = ["righthandindex1", "rightinhandindex", "RightHandIndex1"]
righthandindex2 = ["righthandindex2", "righthandindex1", "RightHandIndex2"]
righthandindex3 = ["righthandindex3", "righthandindex2", "RightHandIndex3"]
rightinhandmiddle = ["rightinhandmiddle", "righthand", "RightInHandMiddle"]
righthandmiddle1 = ["righthandmiddle1", "rightinhandmiddle", "RightHandMiddle1"]
righthandmiddle2 = ["righthandmiddle2", "righthandmiddle1", "RightHandMiddle2"]
righthandmiddle3 = ["righthandmiddle3", "righthandmiddle2", "RightHandMiddle3"]
rightinhandring = ["rightinhandring", "righthand", "RightInHandRing"]
righthandring1 = ["righthandring1", "rightinhandring", "RightHandRing1"]
righthandring2 = ["righthandring2", "righthandring1", "RightHandRing2"]
righthandring3 = ["righthandring3", "righthandring2", "RightHandRing3"]
rightinhandpinky = ["rightinhandpinky", "righthand", "RightInHandPinky"]
righthandpinky1 = ["righthandpinky1", "rightinhandpinky", "RightHandPinky1"]
righthandpinky2 = ["righthandpinky2", "righthandpinky1", "RightHandPinky2"]
righthandpinky3 = ["righthandpinky3", "righthandpinky2", "RightHandPinky3"]


bone_list1 = [hips, spine, spine1, spine2, spine3,neck, head,leftshoulder, leftarm, leftforearm,lefthand,
rightshoulder, rightarm, rightforearm, righthand,
leftupleg, leftleg, leftfoot, lefttoebase,
rightupleg, rightleg, rightfoot, righttoebase,lefthandthumb1,lefthandthumb2,lefthandthumb3,
leftinhandindex,lefthandindex1,lefthandindex2,lefthandindex3,leftinhandmiddle,lefthandmiddle1,lefthandmiddle2,lefthandmiddle3,
leftinhandring,lefthandring1,lefthandring2,lefthandring3,leftinhandpinky,lefthandpinky1,lefthandpinky2,lefthandpinky3,
righthandthumb1,righthandthumb2,righthandthumb3,rightinhandindex,righthandindex1,righthandindex2,righthandindex3,
rightinhandmiddle,righthandmiddle1,righthandmiddle2,righthandmiddle3,rightinhandring,righthandring1,righthandring2,righthandring3,
rightinhandpinky,righthandpinky1,righthandpinky2,righthandpinky3]


bone_list = [hips, spine, spine1, spine2, spine3,neck, head,leftshoulder, leftarm, leftforearm,lefthand,
rightshoulder, rightarm, rightforearm, righthand,
leftupleg, leftleg, leftfoot, lefttoebase,
rightupleg, rightleg, rightfoot, righttoebase]

bone_value={"hips": [0,0,0,0,0,0],"spine3":[0,0,0,0,0,0],"lefthand": [0,0,0,0,0,0],"righthand":[0,0,0,0,0,0]}


# Load dynamic Library
def LoadDll(dllPath):
    if(os.path.exists(dllPath)):
        return CDLL(dllPath)
    else:
        show_log("Chingmu's dynamic Library  does not exist"+dllPath)
        sys.exit()

class chingmuObject(QObject):
    signal = Signal(list)

    def __init__(self) -> None:
        super().__init__()
        self.signal.connect(self.ProcessDataSlot)

    def ProcessDataSlot(self, values):
        global body_device, do_mocap, mocap_avatar,fram1_data,t_pose_data
        if not do_mocap or body_device == None or mocap_avatar == None:
            return
        try:
            body_device.ProcessData(body_device.GetProcessDataIndex(mocap_avatar), values)

        except Exception as e:
            print(e)

frame_object = chingmuObject()

def PrintTimecode(timecode):
    standard = ((timecode & 0x60000000) >> 29)
    hours = ((timecode & 0x1f000000) >> 24)
    minutes = ((timecode & 0x00fc0000) >> 18)
    seconds = ((timecode & 0x0003f000) >> 12)
    frames = ((timecode & 0x00000fe0) >> 5)
    subframes = (timecode & 0x0000001f)
    print("Time code: %d:%d:%d:%d" % (hours, minutes, seconds, frames))

humanT = (c_double * (MAX_SEGMENT_NUM * 3))()
humanLocalR = (c_double * (MAX_SEGMENT_NUM * 4))()

def CMHumanGlobalTLocalRTC(host,humanID,frameCount):
    global cmVrpn,frame_object
    global frame_data,mocap_avatar
    global bone_value,t_pose_data
    global humanT,humanLocalR

    segmentIsDetected = (c_int * MAX_SEGMENT_NUM)()
    timecodeData = (c_int * 1)()
    isHumanDetected = cmVrpn.CMHumanGlobalTLocalRTC(host, humanID, timecodeData, humanT, humanLocalR, segmentIsDetected)
    if (True == isHumanDetected):
        timecode = timecodeData[0]
        valid = ((timecode & 0x80000000) >> 31)
        if(True == valid):
            PrintTimecode(timecode)
        #else:
            #print("server frame num: %d"%(timecode))
        frame_data.clear()

        bone_value["hips"] = [humanT[0], humanT[1], humanT[2],humanLocalR[0], humanLocalR[1], humanLocalR[2], humanLocalR[3]]
        bone_value["spine3"] = [humanT[12], humanT[13], humanT[14],humanLocalR[16], humanLocalR[17], humanLocalR[18], humanLocalR[19]]
        bone_value["lefthand"] = [humanT[30], humanT[31], humanT[32], humanLocalR[40], humanLocalR[41], humanLocalR[42],
                                humanLocalR[43]]
        bone_value["righthand"] = [humanT[42], humanT[43], humanT[44], humanLocalR[56], humanLocalR[57], humanLocalR[58],
                                humanLocalR[59]]

        #Segment
        for i in range(CHINGMU_SEGMENT_NUM-2):
            r = R.from_quat([humanLocalR[i*4], humanLocalR[i*4 + 1], humanLocalR[i*4 + 2], humanLocalR[i*4 + 3]])

            if i > 0:
                if len(t_pose_data) > ((CHINGMU_SEGMENT_NUM-2)*6-1):
                    frame_data.append(t_pose_data[i * 6])
                    frame_data.append(t_pose_data[i * 6 + 1])
                    frame_data.append(t_pose_data[i * 6 + 2])
                    #print("i %d pos x:%f y:%f z:%f" % (i,t_pose_data[i * 6], t_pose_data[i * 6 + 1], t_pose_data[i * 6 + 2]))
            else:
                frame_data.append(bone_value["hips"][0] / 10)
                frame_data.append(bone_value["hips"][1] / 10)
                frame_data.append(bone_value["hips"][2] / 10)
                #print("hips pos x:%f y:%f z:%f" % (bone_value["hips"][0] / 10, bone_value["hips"][1] / 10, bone_value["hips"][2] / 10 ))

            euler = r.as_euler('xyz', degrees=True)
            frame_data.append(euler[0])
            frame_data.append(euler[1])
            frame_data.append(euler[2])

        frame_object.signal.emit(frame_data)
        #print("index 0 pos: X:%f Y:%f Z:%f" % (humanT[0] / 10, humanT[1] / 10, humanT[2]/10))
        #print("quaternion: rx:%f ry:%f rz:%f rw:%f" % ( humanLocalR[0], humanLocalR[1], humanLocalR[2], humanLocalR[3]))
    else:
        print("Human %d not detected" % (humanID))
    return isHumanDetected

timer=QTimer()

def LoadingData():
    global cmVrpn,timer
    # Load dynamic Library
    dllPath = os.path.dirname(os.path.dirname(__file__)) + "/Chingmu_IClone_Plugin_1.0/ChingmuDLL/CMVrpn.dll"
    cmVrpn = LoadDll(dllPath)

    # start vrpn thread
    print("start vrpn thread")
    cmVrpn.CMVrpnStartExtern()

    # enable write trace_log.txt
    print("enable write trace_log.txt")
    cmVrpn.CMVrpnEnableLog(True)

    timer.timeout.connect(runFunc)  # 这里调用不能有函数括号，不是单纯的运行函数
    timer.start(10)
    # 设置时间间隔并启动定时器

# 获取VRPN数据
def runFunc():
    global is_recvdata, host,humanID
    #humanID = 0
    frameCount = 0

    if is_recvdata:
        CMHumanGlobalTLocalRTC(host, humanID, frameCount)

def show_dialog():
    global mocap_dlg
    if mocap_dlg is None:
        mocap_dlg = create_dialog()
        LoadingData()

    if mocap_dlg.isVisible():
        mocap_dlg.hide()
    else:
        update_dialog()
        mocap_dlg.show()

def update_dialog():
    ui_log_edit = mocap_dlg.findChild(PySide2.QtWidgets.QTextEdit, "qtLogText")
    if ui_log_edit:
        ui_log_edit.clear()

    avatar_list = RLPy.RScene.GetAvatars()
    if len(avatar_list) <= 0:
        show_log("Can't find any avatar, please load a avatar first!")
        return


def create_dialog():
    # initialize dialog
    main_widget = wrapInstance(int(RLPy.RUi.GetMainWindow()), PySide2.QtWidgets.QWidget)
    dlg = PySide2.QtWidgets.QDialog(main_widget)  # set parent to main window

    ui_file = QFile(os.path.dirname(__file__) + "/pluginIClone.ui")
    ui_file.open(QFile.ReadOnly)
    ui_widget = PySide2.QtUiTools.QUiLoader().load(ui_file)  # load .ui file
    ui_file.close()
    ui_layout = PySide2.QtWidgets.QVBoxLayout()
    ui_layout.setContentsMargins(0, 0, 0, 0)
    ui_layout.addWidget(ui_widget)
    dlg.setLayout(ui_layout)
    dlg.setWindowTitle("ChingMu Mocap(1.0)")
    dlg.resize(ui_widget.size().width(), ui_widget.size().height())
    dlg.setMinimumSize(ui_widget.size())
    dlg.setMaximumSize(ui_widget.size())

    # connect button signals
    ui_connect_btn = ui_widget.findChild(PySide2.QtWidgets.QPushButton, "qtConnectBtn")
    if ui_connect_btn:
        ui_connect_btn.clicked.connect(do_connect)
    ui_start_btn = ui_widget.findChild(PySide2.QtWidgets.QPushButton, "qtStartBtn")
    if ui_start_btn:
        ui_start_btn.clicked.connect(trigger_mocap)
    return dlg

def calcTposData():
    global bone_value,t_pose_data
    global humanT, humanLocalR
    t_pose_data.clear()
    lastGlobalRotaMatrix = None
    parentGlobalMatrix = None
    hipsGlobalMatrix = None
    spine3GlobalMatrix = None
    LeftHandGlobalMatrix = None
    RightHandlobalMatrix = None
    if bone_value["hips"][2] == 0:
        return False
    for i in range(CHINGMU_SEGMENT_NUM):
        r = R.from_quat([humanLocalR[i*4], humanLocalR[i*4 + 1], humanLocalR[i*4 + 2], humanLocalR[i*4 + 3]])

        if i == 46 or i == 26:
            continue
        if i > 0:
            childrenPosX = humanT[i * 3] / 10
            childrenPosY = humanT[i * 3 + 1] / 10
            childrenPosZ = humanT[i * 3 + 2] / 10

            parentPosX = humanT[(i-1) * 3] / 10
            parentPosY = humanT[(i-1) * 3 + 1] / 10
            parentPosZ = humanT[(i-1) * 3 + 2] / 10

            parentR = R.from_quat(
                [humanLocalR[(i-1) * 4], humanLocalR[(i-1) * 4 + 1], humanLocalR[(i-1) * 4 + 2], humanLocalR[(i-1) * 4 + 3]])

            currentRotaMatrix = r.as_matrix()  # 当前节点旋转矩阵
            if i == 1:#spine
                parentGlobalMatrix = parentR.as_matrix()
                hipsGlobalMatrix = parentGlobalMatrix

            elif i == 4:#spine3
                parentRotaMatrix = lastGlobalRotaMatrix
                spine3GlobalMatrix = np.dot(parentRotaMatrix,currentRotaMatrix)
                parentGlobalMatrix = lastGlobalRotaMatrix

            elif i == 7 or i == 11:#LeftShoulder  RightShoulder
                parentPosX = bone_value["spine3"][0] / 10
                parentPosY = bone_value["spine3"][1] / 10
                parentPosZ = bone_value["spine3"][2] / 10
                parentGlobalMatrix = spine3GlobalMatrix

            elif i == 15 or i == 19:#LeftUpLeg  RightUpLeg
                parentPosX = bone_value["hips"][0] / 10
                parentPosY = bone_value["hips"][1] / 10
                parentPosZ = bone_value["hips"][2] / 10
                parentGlobalMatrix = hipsGlobalMatrix

            elif i == 10:#LeftHand
                parentRotaMatrix = lastGlobalRotaMatrix
                LeftHandGlobalMatrix = np.dot(parentRotaMatrix,currentRotaMatrix)
                parentGlobalMatrix = lastGlobalRotaMatrix

            elif i == 14:#RightHand
                parentRotaMatrix = lastGlobalRotaMatrix
                RightHandlobalMatrix = np.dot(parentRotaMatrix,currentRotaMatrix)
                parentGlobalMatrix = lastGlobalRotaMatrix

            elif i == 23 or i == 27 or i == 31 or i == 35 or i == 39:#LeftHand fingers
                parentPosX = bone_value["lefthand"][0] / 10
                parentPosY = bone_value["lefthand"][1] / 10
                parentPosZ = bone_value["lefthand"][2] / 10
                parentGlobalMatrix = LeftHandGlobalMatrix

            elif i == 43 or i == 47 or i == 51 or i == 55 or i == 59:  #RightHand fingers
                parentPosX = bone_value["righthand"][0] / 10
                parentPosY = bone_value["righthand"][1] / 10
                parentPosZ = bone_value["righthand"][2] / 10
                parentGlobalMatrix = RightHandlobalMatrix

            else:
                parentGlobalMatrix = lastGlobalRotaMatrix

            r_inv = np.transpose(parentGlobalMatrix)# 旋转矩阵转置
            lastGlobalRotaMatrix = np.dot(parentGlobalMatrix,currentRotaMatrix)

            posX = childrenPosX - parentPosX
            posY = childrenPosY - parentPosY
            posZ = childrenPosZ - parentPosZ

            X1 = r_inv[0][0] * posX + r_inv[0][1] * posY + r_inv[0][2] * posZ
            Y1 = r_inv[1][0] * posX + r_inv[1][1] * posY + r_inv[1][2] * posZ
            Z1 = r_inv[2][0] * posX + r_inv[2][1] * posY + r_inv[2][2] * posZ

            #print("index %d pos: X:%f Y:%f Z:%f" % (i,X1, Y1, Z1))

            t_pose_data.append(X1)
            t_pose_data.append(Y1)
            t_pose_data.append(Z1)
            """euler = r.as_euler('xyz', degrees=True)
            t_pose_data.append(euler[0])
            t_pose_data.append(euler[1])
            t_pose_data.append(euler[2])"""

        else:
            t_pose_data.append(bone_value["hips"][0] / 10)
            t_pose_data.append(bone_value["hips"][1] / 10)
            t_pose_data.append(bone_value["hips"][2] / 10)
            print("index %d pos: X:%f Y:%f Z:%f" % (i, bone_value["hips"][0] / 10, bone_value["hips"][1] / 10,bone_value["hips"][2] / 10))
            """euler = r.as_euler('xyz', degrees=True)
            t_pose_data.append(euler[0])
            t_pose_data.append(euler[1])
            t_pose_data.append(euler[2])"""

        t_pose_data.append(0)
        t_pose_data.append(0)
        t_pose_data.append(0)
    return True

def do_connect():
    global mocap_dlg
    global is_connected
    global body_device, mocap_avatar, t_pose_data,frame_data
    global host,humanID
    global cmVrpn,is_recvdata

    avatar_list = RLPy.RScene.GetAvatars()
    if len(avatar_list) <= 0:
        show_log("Can't find any avatar, please load a avatar first!")
        #return
    mocap_avatar = avatar_list[0]

    ui_start_btn = mocap_dlg.findChild(PySide2.QtWidgets.QPushButton, "qtStartBtn")
    # Check Conection
    if is_connected:
        t_pose_data.clear()
        is_connected = False
        is_recvdata = False

        ui_connect_btn = mocap_dlg.findChild(PySide2.QtWidgets.QPushButton, "qtConnectBtn")
        if ui_connect_btn:
            ui_connect_btn.setText("Connect")
        if ui_start_btn:
            ui_start_btn.setDisabled(True)
        return

    if ui_start_btn:
        ui_start_btn.setDisabled(False)

    ui_server_edit = mocap_dlg.findChild(PySide2.QtWidgets.QLineEdit, "qtServerEdit")
    if ui_server_edit == None:
        return

    ui_id_edit = mocap_dlg.findChild(PySide2.QtWidgets.QLineEdit, "qtHumanIDEdit")
    if ui_id_edit == None:
        return

    ui_hipheight_edit = mocap_dlg.findChild(PySide2.QtWidgets.QLineEdit, "qtHipheightEdit")
    if ui_hipheight_edit == None:
        return
    ip_port = ui_server_edit.text()
    human_id = ui_id_edit.text()
    hip_height = ui_hipheight_edit.text()
    host = bytes(ip_port, encoding="utf8")
    humanID = int(human_id)
    hipHeight = float(hip_height)
    print(host)
    isConnectServer = cmVrpn.CMPluginConnectServer(host)

    if (isConnectServer):
        is_recvdata = True
        CMHumanGlobalTLocalRTC(host,humanID,0)
    else:
        return

    show_log("Connect to Server:" + ip_port)
    is_connected = True
    show_log("Connect to Server Succeed")
    show_log("humanID:" + human_id)
    print("hipHeight:")
    print(hipHeight)
    ui_connect_btn = mocap_dlg.findChild(PySide2.QtWidgets.QPushButton, "qtConnectBtn")
    if ui_connect_btn:
        ui_connect_btn.setText("DisConnect")
    if (len(frame_data)) == 0:
        time.sleep(0.2)
    # init mocap data
    mocap_manager.RemoveAllDevices()
    body_device = mocap_manager.AddBodyDevice("bodyDevice")
    body_device.AddAvatar(mocap_avatar)
    body_device.SetEnable(mocap_avatar, True)
    body_setting = body_device.GetBodySetting(mocap_avatar)
    body_setting.SetReferenceAvatar(mocap_avatar)
    #body_setting.SetLockFootRotationState(True)
    body_setting.SetActivePart(RLPy.EBodyActivePart_FullBody)
    #body_setting.SetHipPositionLockedAxes(RLPy.ECoordinateAxes_Z)

    body_setting.SetMotionApplyMode(RLPy.EMotionApplyMode_ReferenceToCoordinate)
    body_device.SetBodySetting(mocap_avatar, body_setting)
    device_setting = body_device.GetDeviceSetting()
    # SetMocapCoordinate ( self, eUpAxis, eFrontAxis, eCoordinateSystem )
    device_setting.SetMocapCoordinate(RLPy.ECoordinateAxis_Z, RLPy.ECoordinateAxis_Y, RLPy.ECoordinateSystem_RightHand)
    device_setting.SetCoordinateOffset(0, [0, 0, 0])

    position_setting = device_setting.GetPositionSetting()
    rotation_setting = device_setting.GetRotationSetting()
    position_setting.SetUnit(RLPy.EPositionUnit_Centimeters)
    body_device.Initialize(bone_list1)

    #set Quaternion
    #rotation_setting.SetType(RLPy.ERotationType_Quaternion)
    #rotation_setting.SetQuaternionOrder(RLPy.EQuaternionOrder_XYZW)
    #rotation_setting.SetCoordinateSpace(RLPy.ECoordinateSpace_Local)
    #position_setting.SetCoordinateSpace(RLPy.ECoordinateSpace_Local)

    #Euler
    rotation_setting.SetType(RLPy.ERotationType_Euler)
    rotation_setting.SetUnit(RLPy.ERotationUnit_Degrees)
    rotation_setting.SetEulerOrder(RLPy.EEulerOrder_XYZ)
    rotation_setting.SetCoordinateSpace(RLPy.ECoordinateSpace_Local)
    #position_setting.SetCoordinateSpace(RLPy.ECoordinateSpace_World)
    position_setting.SetCoordinateSpace(RLPy.ECoordinateSpace_Local)

    ret = calcTposData()
    if ret == True:
        show_log('TPose data Ready')
        # print(t_pose_data_test)
    else:
        show_log('TPose data Not OK')
        return
    tposHipHeight = t_pose_data[2]
    FootBottomToAnkle = hipHeight - tposHipHeight + 0.5
    body_setting.SetFootBottomToAnkle(FootBottomToAnkle)
    FootBottomToAnkle = body_setting.GetFootBottomToAnkle()
    print("FootBottomToAnkle:")
    print(FootBottomToAnkle)

    body_device.SetTPoseData(mocap_avatar, t_pose_data)
    result = body_device.IsTPoseReady(mocap_avatar)
    if result == True:
        show_log('Set TPose')
        #print(t_pose_data_test)
    else:
        show_log('TPose Not OK')
        is_recvdata = False

    # Get Motion Bones
    #skeleton_component = mocap_avatar.GetSkeletonComponent()
    #root_bone = skeleton_component.GetMotionBones()

    print("TPose Data:")
    print(t_pose_data)
    rotation_setting.SetCoordinateSpace(RLPy.ECoordinateSpace_Local)
    position_setting.SetCoordinateSpace(RLPy.ECoordinateSpace_Local)
    show_log("init mocap data finished")


def trigger_mocap():
    global mocap_manager
    global do_mocap
    global mocap_dlg,body_device,fram1_data

    ui_start_btn = mocap_dlg.findChild(PySide2.QtWidgets.QPushButton, "qtStartBtn")
    ui_preview_btn = mocap_dlg.findChild(PySide2.QtWidgets.QRadioButton, "qtPreviewRdo")
    ui_connect_btn = mocap_dlg.findChild(PySide2.QtWidgets.QPushButton, "qtConnectBtn")

    preview_mode = False
    if ui_preview_btn:
        preview_mode = ui_preview_btn.isChecked()
    if not do_mocap:
        do_mocap = True
        if preview_mode:
            show_log("Start mocaping(Preview)...")
            mocap_manager.Start(RLPy.EMocapState_Preview)

        else:
            show_log("Start mocaping(Record)...")
            mocap_manager.Start(RLPy.EMocapState_Record)
        if ui_start_btn:
            ui_start_btn.setText("Cancel")
        if ui_connect_btn:
            ui_connect_btn.setDisabled(True)
    else:
        do_mocap = False
        mocap_manager.Stop()
        show_log("End mocaping...")
        if ui_start_btn:
            ui_start_btn.setText("Start")
        if ui_connect_btn:
            ui_connect_btn.setDisabled(False)


def show_log(message):
    ui_log_edit = mocap_dlg.findChild(PySide2.QtWidgets.QTextEdit, "qtLogText")
    if ui_log_edit == None:
        return
    ui_log_edit.append(message)


def CMPluginConnectServer(host):
    global cmVrpn
    # check Server
    isConnectServer = cmVrpn.CMPluginConnectServer(host)
    if (isConnectServer):
        print("ConnectServer is succeed")
    else:
        print("ConnectServer is failed")
    return isConnectServer

def VrpnQuitExtern():
    global cmVrpn
    # quit vrpn thread
    cmVrpn.CMVrpnQuitExtern()
# iClone python entry
def run_script():           # Menu > Script > Load Python
    initialize_plugin()

def initialize_plugin():    # put into ICPath\Bin64\OpenPlugin
    # Add menu
    ic_dlg = wrapInstance(int(RLPy.RUi.GetMainWindow()), PySide2.QtWidgets.QMainWindow)
    plugin_menu = ic_dlg.menuBar().findChild(PySide2.QtWidgets.QMenu, "pychingmu_menu")
    if (plugin_menu == None):
        plugin_menu = wrapInstance(int(RLPy.RUi.AddMenu("Chingmu Plugin", RLPy.EMenu_Plugins)), PySide2.QtWidgets.QMenu)
        plugin_menu.setObjectName("pychingmu_menu")
    body_mocap_action = plugin_menu.addAction("Chingmu Body Mocap Window")
    body_mocap_action.setObjectName("body_mocap_action")
    body_mocap_action.triggered.connect(show_dialog)
